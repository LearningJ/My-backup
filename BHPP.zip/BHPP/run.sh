./bppr -f ../data/ -g $1 -a $2 -e 0.01 >> log/$1_$2.log
./bppr -f ../data/ -g $1 -a $2 -e 0.001 >> log/$1_$2.log
./bppr -f ../data/ -g $1 -a $2 -e 0.0001 >> log/$1_$2.log
./bppr -f ../data/ -g $1 -a $2 -e 0.00001 >> log/$1_$2.log
./bppr -f ../data/ -g $1 -a $2 -e 0.000001 >> log/$1_$2.log
./bppr -f ../data/ -g $1 -a $2 -e 0.0000001 >> log/$1_$2.log
