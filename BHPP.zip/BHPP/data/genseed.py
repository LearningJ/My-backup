import random
import sys

if __name__=='__main__':
    data = sys.argv[1]
    n = int(sys.argv[2])
    
    with open(data+"/seeds.txt", "w") as f:
        for i in range(100):
            x = random.randint(0, n)
            f.write(str(x)+"\n")
