/*************************************************************************
    > File Name: bppr.cc
    > Author: anryyang
    > Mail: anryyang@gmail.com 
    > Created Time: Thu 28 Sep 2017 02:19:39 PM
 ************************************************************************/

#include<iostream>
#include<boost/program_options.hpp>
#include<string>

#include "graph.h"
#include "algo.h"

using namespace std;
namespace po = boost::program_options;

namespace { 
  const size_t ERROR_IN_COMMAND_LINE = 1; 
  const size_t SUCCESS = 0; 
  const size_t ERROR_UNHANDLED_EXCEPTION = 2; 
 
} // namespace

Config parseParams(int argc, char** argv){
    po::options_description desc("Allowed options");
    desc.add_options()
        ("help,h", "produce help message")
        ("data-folder,f", po::value<string>()->required(), "graph data folder")
        ("graph-name,g", po::value<string>()->required(), "graph file name")
        ("algo,a", po::value<string>()->required(), "algorithm name")
        ("epsilon,e", po::value<double>()->default_value(0), "epsilon")
        ("pfail,p", po::value<double>()->default_value(0), "failure probability")
        ("delta,d", po::value<double>()->default_value(0), "delta")
    ;

    po::variables_map vm; 
    po::store(po::parse_command_line(argc, argv, desc),  vm); // can throw 
    po::notify(vm);

    Config config;

    if (vm.count("help")){
        cout << desc << '\n';
        exit(0);
    }
    if (vm.count("data-folder")){
        config.strFolder = vm["data-folder"].as<string>();
    }
    if (vm.count("graph-name")){
        config.strGraph = vm["graph-name"].as<string>();
    }
    if (vm.count("algo")){
        config.strAlgo = vm["algo"].as<string>();
    }
    if (vm.count("epsilon")){
        config.epsilon = vm["epsilon"].as<double>();
    }
    if (vm.count("delta")){
        config.delta = vm["delta"].as<double>();
    }

    return config;
}

vector<int> loadSeed(string folder, string file_name, int count){
    FILE *fin = fopen((folder + "/" + file_name + "/seeds.txt").c_str(), "r");
    int s;
    vector<int> seeds;
    int i=0;
    while (fscanf(fin, "%d", &s) != EOF) {
        seeds.push_back(s);
        i++;
        if(i>=count)
            break;
    }
    fclose(fin);
    cout << "read seed Done!" << endl;
    return seeds;
}

int main(int argc, char **argv){
    Config config;
    try{
        config = parseParams(argc, argv);
        config.check();
        config.setDefault();
    }
    catch (const exception &ex){
        cerr << ex.what() << '\n';
        return ERROR_IN_COMMAND_LINE;
    }

    config.display();

    int query_count = 100;
    Graph graph(config.strFolder, config.strGraph);
    vector<int> seeds = loadSeed(config.strFolder, config.strGraph, query_count);

    if(config.strAlgo==PISP){
        cout << "start bppr with power-method!" << endl;
        Timer tm(1, "bppr");
        std::vector<double> ppr(graph.getNu());
        double epsilon = config.epsilon/2.0;
        config.setIteration(epsilon);
        cout << "#iterations: " << config.iteration << endl;
        cout << "epsilon: " << epsilon << endl;
        for(const auto& u: seeds){
            powerIter(u, config.alpha, config.iteration, ppr, graph);
        }

        for(const auto& u: seeds){
            reversePush(u, config.alpha, epsilon, ppr, graph);
        }
    }
    else if(config.strAlgo==MCSP){
        cout << "start bppr with monte-carlo!" << endl;
        Timer tm(1, "bppr");
        std::vector<double> ppr(graph.getNu());
        double epsilon = config.epsilon/2.0;
        config.setNumWalks(epsilon, graph.getNu());
        cout << "#randomwalks: " << config.numwalks << endl;
        cout << "epsilon: " << epsilon << endl;
        srand(time(NULL));
        for(const auto& u: seeds){
            monteCarlo(u, config.alpha, config.numwalks, ppr, graph);
        }

        for(const auto& u: seeds){
            reversePush(u, config.alpha, epsilon, ppr, graph);
        }
    }
    else if(config.strAlgo==ABHPP){
        cout << "start bppr with abhpp!" << endl;
        Timer tm(1, "bppr");
        std::vector<double> ppr(graph.getNu());
    	double bepsilon = config.epsilon/(graph.getMaxPR()+1);
    	double fepsilon = bepsilon;
    	cout << "fwd rmax=" << fepsilon << endl;
    	cout << "bwd rmax=" << bepsilon << endl;
        for(const auto& u: seeds){
            BiPartialPush(u, config.alpha, config.epsilon, fepsilon, bepsilon, ppr, graph);
        }
    }
    
    cout << Timer::used(1)*1000/query_count << " milli-seconds per query" << endl;
    Timer::show();

    return SUCCESS;
}
