/*************************************************************************
    > File Name: algo.cc
    > Author: anryyang
    > Mail: anryyang@gmail.com 
    > Created Time: Thu 28 Sep 2017 02:26:32 PM
 ************************************************************************/

#include "algo.h"
#include <math.h>
#include <iostream>
#include <queue>
#include <set>
#include <list>
#include <algorithm>
#include <random>

using namespace std;


void monteCarlo(int src, double alpha, int64 n_walk, std::vector<double>& sppr, const Graph& graph){
    vector<double> ppr(graph.getNu());

    for(int i=0;i<n_walk;i++){
    	int cur = src;
        while(true){
        	if(graph.m_udeg[cur]==0){
        		break;
        	}
        	double stop = (double)rand()/(double)RAND_MAX;
            if(stop<=alpha){
                break;
            }
            else{
            	int k = rand()%graph.m_udeg[cur];
            	cur = graph.m_uedges[cur][k].first;
            	k = rand()%graph.m_vdeg[cur];
            	cur = graph.m_vedges[cur][k].first;
            }
        }
        ppr[cur] += 1;
    }
}

void powerIter(int src, double alpha, uint n_iter, std::vector<double>& sppr, const Graph& graph){
    vector<double> vecUResidue(graph.getNu());
    vector<double> vecVResidue(graph.getNv());
    vector<double> ppr(graph.getNu());

    uint nu = graph.getNu();
    uint nv = graph.getNv();

    vecUResidue[src]= 1.0;
    set<uint> Qu;
    set<uint> Qv;
    Qu.insert(src);

    Timer tm(2, "pi");
    for(int i=0;i<n_iter;i++){
    	for(std::set<uint>::iterator it=Qu.begin(); it!=Qu.end(); ++it){
	        uint u = *it;

	        double residue = vecUResidue[u];
			vecUResidue[u]=0;
			if(graph.m_udeg[u]>0){
				ppr[u] += alpha*residue;
				residue = (1-alpha)*residue;
				for(const auto& p: graph.m_uedges[u]){
					const uint v = p.first;
					const double w = p.second;
					Qv.insert(v);
					vecVResidue[v] += residue*w/(double)graph.m_uwsum[u];
				}
			}
			else{
				ppr[u] += residue;
			}
    	}
    	Qu.clear();

    	for(std::set<uint>::iterator it=Qv.begin(); it!=Qv.end(); ++it){
	        uint v = *it;

	        double residue = vecVResidue[v];
			vecVResidue[v]=0;
			if(graph.m_vdeg[v]>0){
				for(const auto& p: graph.m_vedges[v]){
					const uint u = p.first;
					const double w = p.second;
					Qu.insert(u);
					vecUResidue[u] += residue*w/(double)graph.m_vwsum[v];
				}
			}
    	}
    	Qv.clear();
    }
}

void reversePush(int tgt, double alpha, double eps, std::vector<double>& sppr, const Graph& graph){
    vector<double> vecUResidue(graph.getNu());
    vector<double> vecVResidue(graph.getNv());
    vector<double> ppr(graph.getNu());

    uint nu = graph.getNu();
    uint nv = graph.getNv();

    vecUResidue[tgt]= 1.0;
    set<uint> Qu;
    set<uint> Qv;
    Qu.insert(tgt);
	double thresh = eps;

	Timer tm(3, "bwd");
    while(Qu.size()>0 || Qv.size()>0){
    	for(std::set<uint>::iterator it=Qu.begin(); it!=Qu.end(); ++it){
	        uint u = *it;

	        double residue = vecUResidue[u];
			vecUResidue[u]=0;
			if(graph.m_udeg[u]>0){
				ppr[u] += alpha*residue;
				residue = (1-alpha)*residue;
				for(const auto& p: graph.m_uedges[u]){
					const uint v = p.first;
					const double w = p.second;
					double mass = residue*w/(double)graph.m_vwsum[v];
					Qv.insert(v);
					vecVResidue[v] += mass;
				}
			}
			else{
				ppr[u] += residue;
			}
    	}
    	Qu.clear();

    	for(std::set<uint>::iterator it=Qv.begin(); it!=Qv.end(); ++it){
	        uint v = *it;

	        double residue = vecVResidue[v];
			vecVResidue[v]=0;
			if(graph.m_vdeg[v]>0){
				for(const auto& p: graph.m_vedges[v]){
					const uint u = p.first;
					const double w = p.second;
					double mass = residue*w/(double)graph.m_uwsum[u];
					if(vecUResidue[u]<thresh && vecUResidue[u]+mass>=thresh){
						Qu.insert(u);
					}
					vecUResidue[u] += mass;
				}
			}
    	}
    	Qv.clear();
    }
}


void BiPartialPush(int src, double alpha, double eps, double feps, double beps, std::vector<double>& sppr, const Graph& graph){
    vector<double> vecUResidue(graph.getNu());
    vector<double> vecVResidue(graph.getNv());
    vector<double> ppr(graph.getNu());

    uint nu = graph.getNu();
    uint nv = graph.getNv();

    vecUResidue[src]= 1.0;
    set<uint> Qu;
    set<uint> Qv;
    Qu.insert(src);
	double thresh = beps;

{
	Timer tm(3, "bwd");
	uint iter=0;
    while(Qu.size()>0 || Qv.size()>0){
    	iter++;
    	for(std::set<uint>::iterator it=Qu.begin(); it!=Qu.end(); ++it){
	        uint u = *it;

			double residue = vecUResidue[u];
			vecUResidue[u]=0;
			if(graph.m_udeg[u]>0){
				ppr[u] += alpha*residue;
				residue = (1-alpha)*residue;
				for(const auto& p: graph.m_uedges[u]){
					const uint v = p.first;
					const double w = p.second;
					double mass = residue*w/(double)graph.m_vwsum[v];
					Qv.insert(v);
					vecVResidue[v] += mass;
				}
			}
			else{
				ppr[u] += residue;
			}
    	}
    	Qu.clear();

    	for(std::set<uint>::iterator it=Qv.begin(); it!=Qv.end(); ++it){
	        uint v = *it;

	        double residue = vecVResidue[v];
			vecVResidue[v]=0;
			if(graph.m_vdeg[v]>0){
				for(const auto& p: graph.m_vedges[v]){
					const uint u = p.first;
					const double w = p.second;
					double mass = residue*w/(double)graph.m_uwsum[u];
					if(vecUResidue[u]<thresh && vecUResidue[u]+mass>=thresh){
						Qu.insert(u);
					}
					vecUResidue[u] += mass;
				}
			}
    	}
    	Qv.clear();
    }
}

    thresh = feps;
    double frsum=0;
    double oeps=1.0;
    double frsummax = thresh/oeps;
{
	Timer tm(2, "bwd to fwd");
    for(int u=0; u<graph.getNu(); u++){
    	if(ppr[u]>0){
    		ppr[u]+=graph.getUWsum(u)*ppr[u]/graph.getUWsum(src);
    	}
    	if(vecUResidue[u]>0){
	    	vecUResidue[u]=graph.getUWsum(u)*vecUResidue[u]/graph.getUWsum(src);
	    	frsum+=vecUResidue[u];
	    	if(vecUResidue[u]>thresh){
	    		Qu.insert(u);
	    	}
    	}
    }
}

{   
	Timer tm(4, "fwd");
	uint itr=0;
    while(Qu.size()>0 || Qv.size()>0){
    	if(frsum<=frsummax){
    		break;
    	}
        itr++;
    	for(std::set<uint>::iterator it=Qu.begin(); it!=Qu.end(); ++it){
	        uint u = *it;

			double residue = vecUResidue[u];
			vecUResidue[u]=0;
			if(graph.m_udeg[u]>0){
				ppr[u] += alpha*residue;
				frsum -= alpha*residue;
				residue = (1-alpha)*residue;
				for(const auto& p: graph.m_uedges[u]){
					const uint v = p.first;
					const double w = p.second;
					double mass = residue*w/(double)graph.m_uwsum[u];
					Qv.insert(v);
					vecVResidue[v] += mass;
				}
			}
			else{
				ppr[u] += residue;
				frsum -= residue;
			}
    	}
    	Qu.clear();


    	for(std::set<uint>::iterator it=Qv.begin(); it!=Qv.end(); ++it){
	        uint v = *it;

	        double residue = vecVResidue[v];
			vecVResidue[v]=0;
			if(graph.m_vdeg[v]>0){
				for(const auto& p: graph.m_vedges[v]){
					const uint u = p.first;
					const double w = p.second;
					double mass = residue*w/(double)graph.m_vwsum[v];
					if(vecUResidue[u]<thresh && vecUResidue[u]+mass>=thresh){
						Qu.insert(u);
					}
					vecUResidue[u] += mass;
				}
			}
    	}
    	Qv.clear();
    }
}
}



void fwdPush(int src, double alpha, double eps, double maxpr, std::vector<double>& sppr, const Graph& graph){
    vector<double> vecUResidue(graph.getNu());
    vector<double> vecVResidue(graph.getNv());
    vector<double> ppr(graph.getNu());

    uint nu = graph.getNu();
    uint nv = graph.getNv();

    vecUResidue[src]= 1.0;
    set<uint> Qu;
    set<uint> Qv;
    Qu.insert(src);
	double thresh = eps/maxpr;
{   
	Timer tm(4, "fwd");
	uint itr=0;
    while(Qu.size()>0 || Qv.size()>0){
        itr++;
    	for(std::set<uint>::iterator it=Qu.begin(); it!=Qu.end(); ++it){
	        uint u = *it;

			double residue = vecUResidue[u];
			vecUResidue[u]=0;
			if(graph.m_udeg[u]>0){
				ppr[u] += alpha*residue;
				residue = (1-alpha)*residue;
				for(const auto& p: graph.m_uedges[u]){
					const uint v = p.first;
					const double w = p.second;
					double mass = residue*w/(double)graph.m_uwsum[u];
					Qv.insert(v);
					vecVResidue[v] += mass;
				}
			}
			else{
				ppr[u] += residue;
			}
    	}
    	Qu.clear();


    	for(std::set<uint>::iterator it=Qv.begin(); it!=Qv.end(); ++it){
	        uint v = *it;

	        double residue = vecVResidue[v];
			vecVResidue[v]=0;
			if(graph.m_vdeg[v]>0){
				for(const auto& p: graph.m_vedges[v]){
					const uint u = p.first;
					const double w = p.second;
					double mass = residue*w/(double)graph.m_vwsum[v];
					if(vecUResidue[u]<thresh && vecUResidue[u]+mass>=thresh){
						Qu.insert(u);
					}
					vecUResidue[u] += mass;
				}
			}
    	}
    	Qv.clear();
    }

    double rss=0;
    double rmax=0;
    double rmaxw=0;
    double rsum=0;
    for(int u=0; u<graph.getNu(); u++){
    	if(vecUResidue[u]>0){
    		rss+=vecUResidue[u]*vecUResidue[u];
    		if(vecUResidue[u]>rmax){
    			rmax=vecUResidue[u];
    		}
    		rsum+=vecUResidue[u];
    		if(vecUResidue[u]/graph.getUWsum(u)>rmaxw){
    			rmaxw=vecUResidue[u]/graph.getUWsum(u);
    		}
    	}
    }
    double err1 = sqrt(maxpr*rss);
    double err2 = rmax*maxpr;
    double err3 = rsum;
    double err4 = rmaxw*graph.getMaxUwsum();
    cout << "residue max:" << rmax << " rmax*maxpr:" << " max-pr:" << maxpr << err2 << " epsilon:" << eps << endl;
    cout << "residue/wsum max:" << rmaxw << " maxusum:" << graph.getMaxUwsum() << " error:" << err4 << " epsilon:" << eps << endl;
}	
}
