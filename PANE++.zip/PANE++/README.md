## Description
This is the extended version of PANE for processing graphs with a large attribute set.
The link prediction and attribute inference results are different from those in our conference paper due to the new experimental settings and our new algorithms for these two tasks.

## Env Requirements
- Linux
- Python 2.7

## Datasets
Download from [here](https://renchi.ac.cn/#datasets)


## Data preprocessing
```
$ cd data/
$ python split_train_test.py cora/edgelist.txt 0.3   # split edges into training set (70%) and positive test set (30%)
$ python gen_neg_egdes.py cora/edgelist.txt 0.3      # generate negative test set (30%)

$ python gen_test_neg_attr.py cora/attrs.pkl 0.3     # split attributes into training set (70%) and test set (30%)
```

## Generate embeddings
```
$ mkdir emb
$ mkdir emb/mask/
$ python2.7 paneplus.py --d 128 --full 1 --t 5 --data flickr --kappa 1024    # generate embeddings for node classification
$ python2.7 paneplus.py --d 128 --full 0 --t 5 --data flickr --kappa 1024    # generate embeddings for link prediction
$ python2.7 paneplus.py --d 128 --full 1 --t 5 --data flickr --kappa 1024 --mask 0.7   # generate embeddings for attribute inference
```

## Evaluation
```
$ python node_class.py --algo pane --data cora --d 128    # node classification
$ python link_pred_plus.py --algo pane --data cora --d 128     # link prediction
$ python attr_infer_plus.py --algo pane --data cora --d 128 --ratio 0.7   # attribute inference
```